clear;
clc;
%% H = H0 * 10 * sqrt(10^3)
%% P/(sigma^2) = 10^8;
%% MSE = mse*(10*sqrt(10^3))^2*10^(-8)
N = 4; % Number of antennas
K = 8; % Number of users
Max_Iter = 30000; % Maximum number of iterations
epsilon = 0.0001; % The relative error tolerance
H =  10*channel(K,N);
[w_opt,final_lb,final_ub,lb_sequence,ub_sequence]=BranchBound_MultiCast(H,Max_Iter,epsilon);
num_iter=length(lb_sequence);
figure
plot(1:num_iter,10*log10(ub_sequence/1e5),'LineWidth',2,'color',[153,0,51]/255);
hold on
plot(1:num_iter,10*log10(lb_sequence/1e5),'LineWidth',2,'linestyle','-','color',[2,76,124]/255); % plot the lower and upper bounds sequences 

set(gca,'GridLineStyle','--','GridColor','k','GridAlpha',0.2);
h = legend('Upper bound','Lower bound','SDR');
set(h,'FontSize',14);
xlabel('Iteration Number','FontSize',14);
ylabel('\bf MSE (dB)');
axis([1 num_iter 10*log10(lb_sequence(1,1)/1e5),10*log10(ub_sequence(1,1)/1e5)]);
grid on