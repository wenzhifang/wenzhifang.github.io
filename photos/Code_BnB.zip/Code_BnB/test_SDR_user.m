%% created by wenzhi fang
%% data : 2020 - 11 - 26
%% test the perfoirmance of SDR with 50 times randomiation

clc, clear,close all;
%% system parameters
K_set = 10:5:30; % # of users
N = 10; % # of antennas
exp_num = 50; % Monter Calor Average

mse_SDR = nan(length(K_set),1);
for ii = 1:length(K_set)
    K = K_set(ii);
    tmp_SDR = 0;
    fprintf('Kset = %d\n',ii)
    parfor jj = 1:exp_num  
        H =  10*channel(K,N); %scale *10
         %% Agorithm
        [m, mseSDR] = SDR_Gaussian(H);
        tmp_SDR = tmp_SDR + mseSDR;   
    end
    mse_SDR(ii) = tmp_SDR/exp_num;
end
figure;
plot(K_set,10*log10(mse_SDR/1e3), 'o-','LineWidth',2,'color',[153,0,51]/255,'MarkerSize',10)  
xlabel('Number of users','FontSize',14)
ylabel('MSE','FontSize',14)
legend('SDR')
grid on