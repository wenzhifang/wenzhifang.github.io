function [m, mse] = SDR_Gaussian(H)
%% Semidefinite relaxation with Gaussian Randomizaton (50 times)
times = 30;
[N,K] = size(H);

cvx_begin quiet
cvx_solver sdpt3
variable M(N,N) hermitian semidefinite
minimize (real(trace(M)))
subject to
for k=1:K
     1-real(H(:,k)'*M*H(:,k)) <= 0 ;
end
cvx_end
%% Later steps

%% Leading eigenvector
[u,s] = eigs(M);
m = u(:,1)*sqrt(s(1,1));
mse = MSE(m,H);
%% Gaussian Randomization
if rank(M,1e-6)>1
    [m,mse] = Gaussian_Randomization(M,H,times);
end
end