clc, clear,close all;
%% system parameters
K = 10; % # of users
N_set = 10:10:40; % # of antennas
exp_num = 50; % Monter Calor Average
%% algorithm parameters
%% BnB
Max_Iter = 30000; % Maximum number of iterations
epsilon = 0.0001; % The relative error tolerance
%% DC(SCA)
params.iter_max = 100;
params.verb = 1;
params.rho = 5;

[mse_BnB, mse_SDR, mse_SCA] = deal(nan(length(N_set),1));

for ii = 1:length(N_set)
    N = N_set(ii);
    tmp_BnB = 0;
    tmp_SDR = 0;
    tmp_SCA = 0;
    fprintf('Nset = %d\n',ii)
    parfor jj = 1:exp_num  
        H =  10*channel(K,N); %scale *10
         %% Agorithm
        [a,c,mseSCA,mseSDR,feasibility] = SCA(H);
        [w_opt,final_lb,final_ub,lb_sequence,ub_sequence]=BranchBound_MultiCast(H,Max_Iter,epsilon);
        tmp_SDR = tmp_SDR + mseSDR;   
        tmp_SCA = tmp_SCA + mseSCA;
        tmp_BnB = tmp_BnB + lb_sequence(end);
    end
    mse_SDR(ii) = tmp_SDR/exp_num;
    mse_BnB(ii) = tmp_BnB/exp_num;
    mse_SCA(ii) = tmp_SCA/exp_num;
end
save AP.mat
% figure;
% plot(N_set,10*log10(mse_SDR/1e5), 'o-','LineWidth',2,'color',[153,0,51]/255,'MarkerSize',10) 
% hold on
% plot(N_set,10*log10(mse_SCA/1e5), '>-','LineWidth',2,'color',[140,168,90]/255,'MarkerSize',10)  
% hold on
% plot(N_set,10*log10(mse_BnB/1e5), '*-','LineWidth',2,'color',[2,76,124]/255,'MarkerSize',10)
% xlabel('Number of antennas at AP','FontSize',14)
% ylabel('\bf MSE (dB)','FontSize',14)
% legend('SDR','SCA','Proposed BnB Algorithm')
% grid on
 