function [m,mse] = Gaussian_Randomization(M,H,times)
%% Random 50 times
    [N,~] = size(H);
    for time = 1:times
    zi = chol(M,'lower');
    xi = (randn(N,1) + 1i*randn(N,1))/sqrt(2);
    xi = zi*xi;
    tmp_m = scale(xi,H);
    tmp_mse = MSE(tmp_m,H);
    mse = inf;
    if tmp_mse < mse
        mse = tmp_mse;
        m = tmp_m;
    end
    end
end