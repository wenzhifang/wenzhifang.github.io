function mse = MSE(m,H)
[~,K] = size(H);
mse = 0;
for iter=1:K
    tmp = norm(m)^2/norm(m'*H(:,iter))^2;
    if tmp>mse
        mse = tmp;
    end
end
end