function [a,c,mse_sca,mse_sdr,feasibility] = SCA(H)
[N,K] = size(H);
obj0 = 0;
%H = H*10;
%[a0,mse_sdr,~] = find_M_SDR(H);
[a0, mse_sdr] = SDR_Gaussian(H);
feasibility = 1;
for k = 1:K
    c0(k,:) = [real(a0'*H(:,k)),imag(a0'*H(:,k))]; 
end
maxiter = 100;
for iter = 1:maxiter
    cvx_begin quiet
    cvx_solver sedumi
    variable a(N,1) complex
    variable c(K,2)
    minimize (a'*a)
    subject to
        for k=1:K
           c(k,:) == [real(a'*H(:,k)),imag(a'*H(:,k))];
            2*c0(k,:)*c(k,:)' >= 1+c0(k,:)*c0(k,:)';
        end
    cvx_end
    c0 = c;
    err = abs(cvx_optval-obj0);
    if err<1e-3
        break
    end
    if strcmp(cvx_status,'Infeasible')
        feasibility = 0;
        a = nan;
        c = nan;
        mse_sca = nan;
        return;
    end
    obj0 = cvx_optval;
end

if feasibility ~= 0
    mse_sca = MSE(a,H);
end

end