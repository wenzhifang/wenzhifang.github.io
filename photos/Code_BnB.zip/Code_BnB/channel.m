function H = channel(K,N)
%K: number of user
%N: number of antenna at AP

location_AP = [0,0,20];
%path loss parameter
T0=1; %% T0 = -30 dB P/sigma^2 = 1e8;
a_AU = 2.2;
beta = 3;
Ploss_AU = nan(K,1);
for k = 1:K
    x = 120 + 20*rand;
    y = 20*rand;
    location_user = [x,y,0];
    
    dis_AU = norm(location_AP-location_user);
    Ploss_AU(k) = path_loss(T0,dis_AU,1,a_AU);
end

%% small-scale fading

HNLoS = normrnd(0,1/sqrt(2),N,K)+1i* normrnd(0,1/sqrt(2),N,K);
HLoS = normrnd(0,1/sqrt(2),N,K)+1i*normrnd(0,1/sqrt(2),N,K);
HLoS = HLoS./abs(HLoS);
H = rand(N,K);
for k = 1:K
H(:,k) = sqrt(Ploss_AU(k)) * (HNLoS(:,k)*sqrt(1/(1+beta))+HLoS(:,k)*sqrt(beta/(1+beta))); %channel user to IRS
end

end

function Ploss = path_loss(T0,d,d0,a)
Ploss = T0*(d/d0)^(-a);
end