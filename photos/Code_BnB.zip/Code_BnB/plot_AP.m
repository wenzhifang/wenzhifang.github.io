%% fixed at 2021 4-21 22:00

load('AP.mat')

figure;
plot(N_set,10*log10(mse_SDR/1e5), 'o-','LineWidth',2,'color',[153,0,51]/255,'MarkerSize',10) 
 hold on
plot(N_set,10*log10(mse_SCA/1e5), '>-','LineWidth',2,'color',[140,168,90]/255,'MarkerSize',10)  
hold on
plot(N_set,10*log10(mse_BnB/1e5), '*-','LineWidth',2,'color',[2,76,124]/255,'MarkerSize',10)
xlabel('Number of antennas at AP','FontSize',24)
ylabel('\bf MSE (dB)','FontSize',24)
legend('SDR','SCA','Proposed BnB Algorithm')
grid on

xlabel('Number of antennas at AP','interpreter','latex','FontSize',24)
ylabel('MSE (dB)','interpreter','latex','FontSize',24)
legend({'SDR','SDR-based SCA','Proposed Algorithm'},'interpreter','latex','FontSize',24);
