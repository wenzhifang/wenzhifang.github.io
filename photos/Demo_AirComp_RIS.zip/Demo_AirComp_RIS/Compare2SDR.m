%% Created by Wenzhi Fang
%% date : 2020-12-3 22:53
% The convergence behaviour Alter-Mirror-Prox-SCA, AlterMin SDR, and without IRS.
% check at 20:36 2021-3-30
clearvars;
close all;
clc;

%% RGB color
color1 = [153,0,51]/255;
color2 = [140,168,90]/255;
color3 = [2,76,124]/255;
%% 
N = 30;   %20 No. of Transmit antennas at BS
M = 40;  % No. of elements of IRS
K = 200;  % No. of single antenna users

[Hr,G,Hd]= channel_realization_IRS(K,M,N);
%[Hr,G,Hd]= channel(M,K,N);
%% Parameter
%% Initialization: m(N,1)[x],v(M,1) 
x = (randn(N,1)+1i.*randn(N,1))./sqrt(2);
x = x/norm(x,2);
x_bar = [real(x);imag(x)];

theta = randn(M,1)+1i*rand(M,1);
theta = theta./abs(theta);
v_bar = [real(theta);imag(theta)]; 
ksize = num2cell([N,K,M]);
%% Alternating Mirror prox based SCA
re = zeros(6,1);
for iter = 1:3
[x_bar,min_SNR_MP1] = Mirror_Prox_m(Hd,G,Hr,ksize,x_bar,v_bar);
value = min_SNR_MP1 - 120;
value = 10.^(value/10);
semilogy(value,'-*','LineWidth',2,'color',color3,'MarkerSize',8);
re(2*iter-1,1) = min_SNR_MP1(end,1);
[v_bar,min_SNR_MP2] = Mirror_Prox_v(Hd,G,Hr,ksize,x_bar,v_bar);
value = min_SNR_MP2 - 120;
value = 10.^(value/10);
semilogy(value,'-*','LineWidth',2,'color',color3,'MarkerSize',8);
re(2*iter,1) = min_SNR_MP2(end,1);
end
value = re - 120;
value = 10.^(value/10);
x = 1:1:6;
semilogy(x,value,'-*','LineWidth',2,'color',color1,'MarkerSize',8);

%% AlterMin SDR
[~,~,mse_set] = AlterMin_SDR(Hd,Hr,G,10,theta); % 10 is the iteration times
value = re - 120;
value = 10.^(value/10);
sdr_value = mse_set-120;
sdr_value = sdr_value(~isnan(sdr_value));
sdr_value = 10.^(sdr_value/10);
x = 1:1:6;
semilogy(x,value,'-*','LineWidth',2,'color',color1,'MarkerSize',8);
hold on 
x = length(sdr_value);
semilogy(1:1:x,sdr_value,'-d','LineWidth',2,'color',color3,'MarkerSize',8);
grid on
xlabel('Number of iteration','interpreter','latex','FontSize',14)
ylabel('\bf MSE','interpreter','latex','FontSize',14)
legend({'Proposed Mirror Prox based SCA','Alternating SDR'},'interpreter','latex','FontSize',14)


% print(gcf,'-depsc','./test_saveas2.eps')
% saveas(gcf,'./test_saveas.fig')
%% Without IRS
% v_bar = zeros(2*M,1);
% [~,mse_wo] = Mirror_Prox_m(2*Hd,G,Hr,ksize,x_bar,v_bar);
