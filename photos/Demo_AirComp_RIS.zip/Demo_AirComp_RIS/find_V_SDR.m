function [y,feasibility ]= find_V_SDR(m,Hd,Hr,G)
[N,K] = size(Hd);
[~,M] = size(G);

cvx_begin quiet
%                 cvx_solver sedumi
variable V(M+1,M+1) hermitian semidefinite
minimize (0)
subject to
for k=1:K
    a_H = m'*G*diag(Hr(:,k));
    a = a_H';
    c = m'*Hd(:,k);
    R = [a*a',a*c;c'*a',0];
    real(trace(R*V)+c'*c) >= 1;
end
real(diag(V)) == 1;
cvx_end

if strcmp(cvx_status,'Infeasible') == 1 
    feasibility = 0;
    y = [];
    return; 
end

if rank(V,1e-6) == 1
    [u,s,v] = svd(V);
    y_bar = u(:,1)*sqrt(s(1,1));
    y = y_bar(1:M)/y_bar(end);
%     y = y./abs(y);
    feasibility = check_feasible(y,m,Hd,Hr,G);
else
    for ii = 1:1000
        zi = chol(V,'lower');
        xi = (randn(M+1,1)+1i*randn(M+1,1))/sqrt(2);
        xi = zi*xi;        
        tmp = inf;
        for k=1:K
            a_H = m'*G*diag(Hr(:,k));
            a = a_H';
            c = m'*Hd(:,k);
            R = [a*a',a*c;c'*a',0];
            alpha = real(xi'*R*xi);
            if real(c'*c) < 1
               p = (1-c'*c)/sqrt(alpha); 
            else
               p= inf;
            end
            if p< tmp
                tmp = p;
            end
        end
        if tmp<inf
            y_bar = xi/sqrt(tmp);
        else
            y_bar = xi;
        end
        y = y_bar(1:M)/y_bar(end);
        y = y./abs(y);
        feasibility = check_feasible(y,m,Hd,Hr,G);
        if feasibility == 1
            break;
        end
    end       
end
end