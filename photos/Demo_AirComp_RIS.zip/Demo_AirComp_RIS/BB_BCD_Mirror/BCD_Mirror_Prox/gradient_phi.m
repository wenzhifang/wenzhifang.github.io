function g = gradient_phi(z,N)

x = z(1:2*N); y = z(2*N+1:end);

g = [x;log(y)+1];
end