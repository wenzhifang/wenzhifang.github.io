function z_p = breg_proj(z,N,q)

x = z(1:2*N); y = z(2*N+1:end);


%% Project onto Feasible Set

if (norm(x(1:2*N,1),2) > q)
    x_p = sqrt(q)*x(1:2*N,1)/norm(x(1:2*N,1),2);
else
    x_p = x(1:2*N,1);
end

%% Project onto Probability Simplex

if(all(y>0) && sum(y)==1)
    y_p = y;
else
    y_p = y./norm(y,1);
end

z_p = [x_p;y_p];
end