function w = inv_gradient_phi(g,N)

x = g(1:2*N); p = g(2*N+1:end);

w = [x;exp(p-1)];
end