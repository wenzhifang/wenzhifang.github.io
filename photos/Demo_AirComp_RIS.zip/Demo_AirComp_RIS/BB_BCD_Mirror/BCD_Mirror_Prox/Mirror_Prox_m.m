function [x_sum,MSE_MP] = Mirror_Prox_m(Hd,G,Hr,ksize,x_bar,v_bar)

MAX_OUTER_ITS = 2e1; % Total No. of SCA iterations
MAX_INNER_ITS = 1e3; % Max No. of iterations used to solve each SCA subproblem (keep withn 1k-5k range for best results)
power_val = 1; % Power budget for each antenna
e_spmp = 1e-6; % Stopping tolerance for Saddle-Point Mirror-Prox 

[N,K,M] = deal(ksize{:});
        
%% Channel vectors
theta = v_bar(1:M,1) + 1j*v_bar(M+1:2*M,1);
Theta = diag(theta);
R = zeros(2*N,2*N,K);
for k = 1:K
    h = G*Theta*Hr(:,k)+Hd(:,k); % Rayliegh fading channel model; can consider other channel models as well; use what is relevant to your reseacrh!
    H = -h*h';
    H_real = real(H); H_imag = imag(H);
    R(:,:,k) = [H_real, -H_imag; H_imag, H_real];%/1e-5; % scale : (10^3)*(10^5)
end
%% Initialization
% R(:,:,k) := -hat{H}_k
%% SCA using Saddle Point - Mirror Prox
m_hat = x_bar;
MSE_MP(1,1) = min_SNR(m_hat,R);
for i = 1:MAX_OUTER_ITS
    %% SCA
    PT = zeros(2*N,K); q = zeros(K,1);
    %PT = P^{T}
    P_Norm = zeros(K,1);

    for k = 1:K
        PT(:,k) = 2*R(:,:,k)*m_hat; 
        q(k) = -m_hat'*R(:,:,k)*m_hat; 
        P_Norm(k) = norm(PT(:,k),2);
    end
    lambda = 1/(2*max(P_Norm));
    x = m_hat;
    y = (1/K).*ones(K,1);
    z = [x;y];

    x_sum  = zeros(2*N,1);
    %% Mirror Prox
    for j = 1:MAX_INNER_ITS

        x = z(1:2*N); y = z(2*N+1:end);

        gradient_phi_w_bar = gradient_phi(z,N)-lambda*[PT*y;-(PT'*x+q)];            
        w_bar = inv_gradient_phi(gradient_phi_w_bar,N);            
        w = breg_proj(w_bar,N,power_val);

        u = w(1:2*N); v = w(2*N+1:end);

        gradient_phi_z_bar = gradient_phi(z,N)-lambda*[PT*v;-(PT'*u+q)];
        z_bar = inv_gradient_phi(gradient_phi_z_bar,N); 
        z = breg_proj(z_bar,N,power_val);

        x_bar = z(1:2*N); y_bar = z(2*N+1:end);
        %Vx = 0.5*(norm(x_bar,2)^2-norm(x,2)^2)-x'*(x_bar-x);
%% Compute the distance of z^t and z^{t+1} := Vz = Vx + Vy
        Vx = 0.5*(norm(x_bar-x,2)^2);
        y_sum = 0;
        if(all(abs(y-y_bar))~=0)
            for k = 1:K
                y_sum = y_sum + y_bar(k)*log(y_bar(k)/y(k));
            end
        end
        Vy = y_sum - sum(y_bar-y);
        Vz = Vx+Vy;

        if(j == 1)
            x_sum = x_bar;
        else
            x_sum = ((j-1)*x_sum+x_bar)/j;
        end

        if(Vz <= e_spmp)
           %j
           %disp('Boom!');
           break;
        end
    end
    %Vz
    MSE_MP(i+1,1) = min_SNR(x_sum,R);
    m_hat = x_sum;
%     MSE_MP(i+1,1) = min_SNR(x_bar,R);
%     m_hat = x_bar;
end

end