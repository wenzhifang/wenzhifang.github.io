%%  2021-7-14     fang wenzhi
%% revised 2021-7-14
clc,clear,close all;

addpath('./BCD_three_block')
%% Parameter for BCD SNR 120dB
P = 1;
sigma = 1e-12;

%% parameter settings
K = 200; % # of users
M = 50; % # of elements
exp_num = 500;
N_set = 10:10:50;
iter_max = 6;

mse_MP_IRS = nan(length(N_set),1);
mse_BCD_IRS = nan(length(N_set),1);
T_MP = nan(length(N_set),1);
T_BCD = nan(length(N_set),1);
parpool(50)
for ii = 1:length(N_set)
    N = N_set(ii);
    %% MSE  

    tmp_MP_IRS = 0;
    
    tmp_BCD_IRS = 0;
    %% time
    tmp_t_MP = 0;
    tmp_t_BCD = 0;
    fprintf('AP Number = %d\n',N)
    parfor jj = 1:exp_num
        jj
        [Hr,G,Hd]= channel_realization_IRS(K,M,N);
        %% Mirror_Prox
        tic
        [re] = Mirror_Prox(N,M,K,Hd,Hr,G);
        tmp_T = toc;
      
        tmp_t_MP = tmp_t_MP + tmp_T;
        tmp_MP_IRS = tmp_MP_IRS + re(end);
       
        
        %% BCD
        tic
        MSE = BCD_main(Hd,G,Hr,P,sigma)
        tmp_T = toc;
        tmp_t_BCD = tmp_t_BCD + tmp_T;
        
        tmp_BCD_IRS = tmp_BCD_IRS+MSE(end);
        disp('BCD');
        
    
    end
   
    mse_MP_IRS(ii) = tmp_MP_IRS/exp_num;
    mse_BCD_IRS(ii) = tmp_BCD_IRS/exp_num;
    T_MP(ii) = tmp_t_MP/exp_num;
    T_BCD(ii) = tmp_t_BCD/exp_num;
    
end

mse_MP_IRS_value = mse_MP_IRS - 120;
mse_MP_IRS_value = 10.^(mse_MP_IRS_value/10);

mse_IRS_SDR_value = mse_BCD_IRS;

save ./Data_BCD_Mirror/dataAP.mat
