function MSE = post_projection(Hd,G,Hr,ksize,x_bar,v_bar)

[N,K,M] = deal(ksize{:});
%% Channel vectors
m_n = x_bar(1:N,1)+1j*x_bar(N+1:2*N,1);
R = zeros(2*M,2*M,K);
D = zeros(2*M,K);
c = zeros(K,1);
for k = 1:K
    c(k,1) = m_n'*Hd(:,k); 
    a_H = m_n'*G*diag(Hr(:,k));
    D(:,k) = [real(c(k,1)*a_H');imag(c(k,1)*a_H')]; % b_k = [real(c_k*a)^T,imag(c_k*a)^T]^T
    H = -a_H'*a_H; 
    H_real = real(H); H_imag = imag(H);
    R(:,:,k) = [H_real, -H_imag; H_imag, H_real];%/1e-5; % SNR matrix in real form
end
x = v_bar;
x_p = zeros(2*M,1);
for i = 1:M
       x_p(i) = x(i)/sqrt(x(i)^2+x(i+M)^2);
       x_p(i+M) = x(i+M)/sqrt(x(i)^2+x(i+M)^2);
end
MSE = min_V_SNR(x_p,R,D,c);
end