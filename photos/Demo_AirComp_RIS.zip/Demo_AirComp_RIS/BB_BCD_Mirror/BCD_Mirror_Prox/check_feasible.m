function feasible = check_feasible(v,m,Hd,Hr,G)
[~,K] = size(Hd);
feasible = 1;
if nargin == 3
   for k=1:K
        tmp = m'*Hd(:,k);
%         tmp'*tmp -1
        if abs(tmp)^2+1e-7 < 1
            feasible=0;
        end
    end 
else       
    Theta = diag(v);
    for k=1:K
        tmp = m'*(G*Theta*Hr(:,k)+Hd(:,k));
%         tmp'*tmp - 1
        if abs(tmp)^2+1e-7 < 1
            feasible=0;
        end
    end
end

end