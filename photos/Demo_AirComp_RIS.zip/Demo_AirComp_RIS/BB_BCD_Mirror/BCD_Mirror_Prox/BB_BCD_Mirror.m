%%  2021-7-23     fang wenzhi
%% revised 2021-7-23
clc,clear,close all;
addpath('./BCD_three_block')
%% Parameter for BCD SNR 120dB
P = 1;
sigma = 1e-12;

%% parameter settings
K = 30; % # of users
M = 20; % # of elements
exp_num = 200;
N_set = 5:5:25;
iter_max = 6;

mse_MP_IRS = nan(length(N_set),1);
mse_BCD_IRS = nan(length(N_set),1);
mse_BB_IRS = nan(length(N_set),1);

parpool(50)
for ii = 1:length(N_set)
    N = N_set(ii);
    %% MSE  
    tmp_MP_IRS = 0;
    tmp_BCD_IRS = 0;
    tmp_BB_IRS = 0;
  
    fprintf('AP Number = %d\n',N)
    parfor jj = 1:exp_num
        jj
        [Hr,G,Hd]= channel_realization_IRS(K,M,N);
        %% Mirror_Prox
        [re] = Mirror_Prox(N,M,K,Hd,Hr,G);
        tmp_MP_IRS = tmp_MP_IRS + re(end);
 
        %% BCD
        MSE = BCD_main(Hd,G,Hr,P,sigma)
        tmp_BCD_IRS = tmp_BCD_IRS+MSE(end);
        disp('BCD');
        
        %% BCD BB
        MSE = BCD_BB_main(Hd,G,Hr,P,sigma)
        tmp_BB_IRS = tmp_BB_IRS+MSE(end);
        disp('BB');
    
    end
    mse_MP_IRS(ii) = tmp_MP_IRS/exp_num;
    mse_BCD_IRS(ii) = tmp_BCD_IRS/exp_num;
    mse_BB_IRS(ii) = tmp_BB_IRS/exp_num;
end

mse_MP_IRS_value = mse_MP_IRS - 120;
mse_MP_IRS_value = 10.^(mse_MP_IRS_value/10);

save ./BB_BCD_Mirror/dataAP.mat
