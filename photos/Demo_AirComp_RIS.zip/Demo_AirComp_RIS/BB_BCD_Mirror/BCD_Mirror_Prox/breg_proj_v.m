function z_p = breg_proj_v(z,N,q)

x = z(1:2*N); y = z(2*N+1:end);


%% Project onto Feasible Set
%{
if (norm(x(1:2*N,1),2) > q)
    x_p = sqrt(q)*x(1:2*N,1)/norm(x(1:2*N,1),2);
else
    x_p = x(1:2*N,1);
end
%}
%x_p = sqrt(q)*x(1:2*N,1)/norm(x(1:2*N,1),2);

%% massive mimo   
x_p = zeros(2*N,1);
for i = 1:N
    if(x(i)^2+x(i+N)^2 < q)
       x_p(i) = x(i); x_p(i+N) = x(i+N);
    else
       x_p(i) = sqrt(q)*x(i)/sqrt(x(i)^2+x(i+N)^2);
       x_p(i+N) = sqrt(q)* x(i+N)/sqrt(x(i)^2+x(i+N)^2);
    end
end

%% Project onto Probability Simplex

if(all(y>0) && sum(y)==1)
    y_p = y;
else
    y_p = y./norm(y,1);
end

z_p = [x_p;y_p];