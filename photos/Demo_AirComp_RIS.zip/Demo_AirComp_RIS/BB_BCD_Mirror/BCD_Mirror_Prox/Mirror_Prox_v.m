function [v_bar,MSE_MP] = Mirror_Prox_v(Hd,G,Hr,ksize,x_bar,v_bar)

MAX_OUTER_ITS = 2e1; % Total No. of SCA iterations
MAX_INNER_ITS = 1e4; % Max No. of iterations used to solve each SCA subproblem (keep withn 1k-5k range for best results)
power_val = 1; % Power budget for each antenna

e_spmp = 1e-6; % Stopping tolerance for Saddle-Point Mirror-Prox 

[N,K,M] = deal(ksize{:});
        
%% Channel vectors
m_n = x_bar(1:N,1)+1j*x_bar(N+1:2*N,1);
R = zeros(2*M,2*M,K);
D = zeros(2*M,K);
c = zeros(K,1);
for k = 1:K
    c(k,1) = m_n'*Hd(:,k); 
    a_H = m_n'*G*diag(Hr(:,k));
    D(:,k) = [real(c(k,1)*a_H');imag(c(k,1)*a_H')]; % b_k = [real(c_k*a)^T,imag(c_k*a)^T]^T
    H = -a_H'*a_H; 
    H_real = real(H); H_imag = imag(H);
    R(:,:,k) = [H_real, -H_imag; H_imag, H_real];%/1e-5; % SNR matrix in real form
end

%% SCA using Saddle Point - Mirror Prox
p_MP = v_bar;
MSE_MP(1,1) = min_V_SNR(p_MP,R,D,c);

for i = 1:MAX_OUTER_ITS
    %i
  
    A = zeros(2*M,K); b = zeros(K,1);
    P_norm = zeros(K,1);

    for k = 1:K
        A(:,k) = (2*R(:,:,k)*p_MP - 2*D(:,k)); 
        b(k) = (-p_MP'*R(:,:,k)*p_MP - abs(c(k,1))^2); 
        %b(k) = -p_MP'*R(:,:,k)*p_MP; 
        P_norm(k) = norm(A(:,k),2);
    end
    L = max(P_norm);
    v = p_MP;
    y = (1/K).*ones(K,1);
    
    z = [v;y];

    lambda = 1/(2*L);

    x_sum  = zeros(2*M,1);

    for j = 1:MAX_INNER_ITS

        x = z(1:2*M); y = z(2*M+1:end);
  
        gradient_phi_w_bar = gradient_phi(z,M)-lambda*[A*y;-(A'*x+b)];            
        w_bar = inv_gradient_phi(gradient_phi_w_bar,M);            
        w = breg_proj_v(w_bar,M,power_val);

        u = w(1:2*M); v = w(2*M+1:end);

        gradient_phi_z_bar = gradient_phi(z,M)-lambda*[A*v;-(A'*u+b)];
        z_bar = inv_gradient_phi(gradient_phi_z_bar,M); 
        z = breg_proj_v(z_bar,M,power_val);

        v_bar = z(1:2*M); y_bar = z(2*M+1:end);
        if(j == 1)
            x_sum = v_bar;
        else
            x_sum = ((j-1)*x_sum+v_bar)/j;
        end

        Vx = 0.5*(norm(v_bar-x,2)^2);
        y_sum = 0;
        
        if(all(abs(y-y_bar))~=0)
            for k = 1:K
                y_sum = y_sum + y_bar(k)*log(y_bar(k)/y(k));
            end
        end
        Vy = y_sum - sum(y_bar-y);
        Vz = Vx+Vy;

       
        if(Vz <= e_spmp)
           %j
           %disp('Boom!');
           break;
        end
        
    end
    %Vz
    MSE_MP(i+1,1) = min_V_SNR(x_sum,R,D,c);
    p_MP = x_sum;
end
v_bar = x_sum;
end
