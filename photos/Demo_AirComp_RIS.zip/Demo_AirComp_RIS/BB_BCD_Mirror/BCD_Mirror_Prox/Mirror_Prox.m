function [re] = Mirror_Prox(N,M,K,Hd,Hr,G)
%% Parameter
%% Initialization: m(N,1)[x],v(M,1) 
x = (randn(N,1)+1i.*randn(N,1))./sqrt(2);
x = x/norm(x,2);
x_bar = [real(x);imag(x)];

theta = randn(M,1)+1i*rand(M,1);
theta = theta./abs(theta);
v_bar = [real(theta);imag(theta)]; 
ksize = num2cell([N,K,M]);

re = zeros(6,1);
for iter = 1:3
[x_bar,min_SNR_MP1] = Mirror_Prox_m(Hd,G,Hr,ksize,x_bar,v_bar);
re(2*iter-1,1) = min_SNR_MP1(end,1);
[v_bar,min_SNR_MP2] = Mirror_Prox_v(Hd,G,Hr,ksize,x_bar,v_bar);
re(2*iter,1) = min_SNR_MP2(end,1);
end
end