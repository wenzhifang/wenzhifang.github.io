function [Hr,G,Hd]= channel_realization_IRS(K,M,N)
%K: number of user
%M: number of elements at IRS
%N: number of antenna at AP

location_AP = [0,0,20];
location_IRS = [100,20,20];
%location_IRS = [80,0,20];
%path loss parameter
TD=10^(-3);
TR=10^(-3);
a_AI = 2.2;
a_AU = 3.67;
a_IU = 2.2;
beta = 3;
dis_AI = norm(location_AP-location_IRS);
Ploss_AI = TR*path_loss(dis_AI,1,a_AI);

Ploss_AU = nan(K,1);
Ploss_IU = nan(K,1);
for k = 1:K
%    theta = 2*pi*rand;
%     x = 60+20*cos(theta);
%     y = 20*sin(theta);
     x = 120 + 20*rand;
     y = 20*rand;
    location_user = [x,y,0];
    
    dis_AU = norm(location_AP-location_user);
    Ploss_AU(k) = TD*path_loss(dis_AU,1,a_AU);
    
    dis_IU = norm(location_IRS-location_user);
    Ploss_IU(k) = TR*path_loss(dis_IU,1,a_IU);
end
NLOS = sqrt(1/(1+beta));
LOS = sqrt(beta/(1+beta));
%% small-scale fading
G =  normrnd(0,1/sqrt(2),N,M)+1i* normrnd(0,1/sqrt(2),N,M);
G = sqrt(Ploss_AI)*(NLOS*G+LOS*ones(N,M)); %channe IRS to AP

Hd = normrnd(0,1/sqrt(2),N,K)+1i* normrnd(0,1/sqrt(2),N,K);
Hr = normrnd(0,1/sqrt(2),M,K)+1i* normrnd(0,1/sqrt(2),M,K); 
for k = 1:K
Hd(:,k) = sqrt(Ploss_AU(k)) * Hd(:,k);  %channel user to AP
Hr(:,k) = sqrt(Ploss_IU(k)) * (NLOS*Hr(:,k)+LOS*ones(M,1)); %channel user to IRS
end

end

function Ploss = path_loss(d,d0,a)
Ploss = (d/d0)^(-a);
end