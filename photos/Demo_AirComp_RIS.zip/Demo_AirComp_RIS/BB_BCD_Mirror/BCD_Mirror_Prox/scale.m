function m = scale(x,H)
%% Enforce the m to adimit the constraint
[~,K] = size(H);
min_eig = inf;
for k=1:K
    tmp = abs(x'*H(:,k));
    if tmp<min_eig
        min_eig = tmp;
    end
end
m = x/min_eig;

end