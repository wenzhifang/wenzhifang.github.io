function maxMSE = min_SNR(x,A)
%% MSE = max { |m|^2 / |(m^H) * (h_k)|^2 } 
%% MSE = max { |m|^2 / (m^H) * (h_k)*(h_k)^H * m } 
K = size(A,3);
MSE = zeros(K,1);
    for j = 1:K
        MSE(j) = norm(x)^2/(x'*(-A(:,:,j))*x);
    end
maxMSE = 10*log10(max(MSE));
end

