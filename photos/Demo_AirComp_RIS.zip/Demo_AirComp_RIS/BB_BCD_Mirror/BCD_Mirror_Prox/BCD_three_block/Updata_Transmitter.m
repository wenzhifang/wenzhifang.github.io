function [W, mse_w] = Updata_Transmitter(Hd,G,Hr,Theta,f,P,sigma)

[~,K] = size(Hd);
for k=1:K
    ck = (Hd(:,k)+G*Theta*Hr(:,k))'*f;
    if abs(ck)^2*P > 1
        W(k) = ck/(abs(ck))^2;
    else
        W(k) = sqrt(P)*ck/abs(ck);
    end
end

mse_w = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma);

end