function mse = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma)

[~,K] = size(Hd);

tmp = zeros(K,1);

for k=1:K
    tmp(k) = f'*(Hd(:,k)+G*Theta*Hr(:,k))*W(k) - 1;
    tmp(k) = abs(tmp(k))^2;
end
mse = sum(tmp) + sigma*(norm(f))^2;

end


