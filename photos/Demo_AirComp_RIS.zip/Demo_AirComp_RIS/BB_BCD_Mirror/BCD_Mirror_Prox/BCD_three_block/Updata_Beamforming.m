function [f,mse_f] = Updata_Beamforming(Hd,G,Hr,Theta,W,sigma)

[M,~] = size(Hd);
[~,K] = size(Hd);

tmp = zeros(M,1);
A = sigma*eye(M);

for k = 1:K
    hk = (Hd(:,k)+G*Theta*Hr(:,k))*W(k);
    A = A+hk*hk';
    tmp = tmp+hk;
end

f = A\tmp;

mse_f = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma);

end