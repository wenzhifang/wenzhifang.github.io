
K = 10;
M = 10;
N = 10;

[Hr, G, Hd] = channel_realization_IRS(K,N,M);

P = 0.1;

sigma = 1e-6;

MSE1 = BCD_BB_main(Hd,G,Hr,P,sigma);
MSE2 = BCD_main(Hd,G,Hr,P,sigma);


% P = 1;
% 
% sigma = 1e-5;
% 
% MSE2 = BCD_main(Hd,G,Hr,P,sigma);
% 
% 
% P = 10;
% 
% sigma = 1e-4;
% 
% MSE3 = BCD_main(Hd,G,Hr,P,sigma);
% 
% 
% P = 100;
% 
% sigma = 1e-3;
% 
% MSE4 = BCD_main(Hd,G,Hr,P,sigma);
% 
semilogy(MSE1, 'o--','LineWidth',3,'color','r','MarkerSize',12)  
hold on
semilogy(MSE2, '*-','LineWidth',3,'color','g','MarkerSize',12) 
% hold on
% semilogy(MSE3, '->','LineWidth',3,'color','b','MarkerSize',12) 
% hold on
% semilogy(MSE4, '-s','LineWidth',3,'color','y','MarkerSize',12) 
