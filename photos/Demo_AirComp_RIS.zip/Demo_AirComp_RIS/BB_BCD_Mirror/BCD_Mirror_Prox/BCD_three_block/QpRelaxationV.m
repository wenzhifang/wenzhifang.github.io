function [v, objval, feas] = QpRelaxationV(omega, eta, m, Hr, G, Hd, l, u)
% min  0
% s.t. |m'Gdiag(hr(:, k))v + m'hd(:, k)| >= 1, k = 1,...,K
%      abs(v_n) = 1,

% K: # of users
% N: # of antennas
% M: # of elements

[M, K] = size(Hr);
[N, ~] = size(G);

%%
cvx_begin quiet sdp
variable v(M, 1) complex
variable V(M+1, M+1) hermitian semidefinite

expression summation
    for k = 1:K
        ak = (omega(k)/sqrt(eta))*m'*G*diag(Hr(:, k));
        bk = 1 - omega(k)*m'*Hd(:, k);
        R = [ak'*ak, -ak'*bk; -bk'*ak, 0];
        summation = summation + (real(trace(R*V)) + bk'*bk);
    end

minimize summation
subject to
    real(diag(V)) == 1;
    for t = 1:(M)
        ut = u(t);
        lt = l(t);
        cc = cos((ut + lt)/2) + 1j*sin((ut + lt)/2);
        real(cc'*v(t)) >= cos((ut - lt)/2);
    end
    tmp = [v; 1];
    [1, tmp'; tmp, V] >= 0;
cvx_end

feas = 1;
if strcmp(cvx_status, 'Infeasible') == 1 
    feas = -1;
    v = [];
    return; 
end

%%
objval = cvx_optval;
