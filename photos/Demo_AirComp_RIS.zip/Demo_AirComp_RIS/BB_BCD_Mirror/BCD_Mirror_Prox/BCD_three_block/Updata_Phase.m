function [Theta,mse_theta] = Updata_Phase(Hd,G,Hr,f,W,Theta,sigma)

[N,~] = size(Theta); 
[~,K] = size(Hd);
for k =1:K
    A(:,k) = (W(k)*f'*G*diag(Hr(:,k)))';
    b(k) = 1-W(k)*f'*Hd(:,k);
end

v = diag(Theta);

for count = 1:5

for n=1:N
    tmp = 0;
    for k=1:K
        tiltde_b(k) = b(k) - A(:,k)'*v + A(n,k)'*v(n);
        tmp = tmp + A(n,k)*tiltde_b(k);
    end
    tmp1 = tmp/(norm(A(n,:)))^2;
    v(n) = tmp1/abs(tmp1);
%     Theta = diag(v);
%     mse_theta = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma);
%     mse_theta
end
end

Theta = diag(v);
mse_theta = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma);


end
