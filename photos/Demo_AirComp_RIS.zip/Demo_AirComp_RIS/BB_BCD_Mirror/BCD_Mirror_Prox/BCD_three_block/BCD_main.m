function MSE = BCD_main(Hd,G,Hr,P,sigma)

iter = 0;
% MSE = Nan(10000,1);
[~,N] = size(G); 
[~,K] = size(Hd);
MSE = zeros(300,1);
%% Initialize (Theta W)
W = sqrt(P)*ones(K,1); 
Theta = diag(exp(1i*2*pi*rand(1,N)));
for i = 1:100
    [f,mse_f] = Updata_Beamforming(Hd,G,Hr,Theta,W,sigma);
    MSE(iter+1) = mse_f;
    [W, mse_w] = Updata_Transmitter(Hd,G,Hr,Theta,f,P,sigma);
    MSE(iter+2) = mse_w;
    [Theta,mse_theta] = Updata_Phase(Hd,G,Hr,f,W,Theta,sigma);
    MSE(iter+3) = mse_theta;
    
    iter = iter+3;
end

end
