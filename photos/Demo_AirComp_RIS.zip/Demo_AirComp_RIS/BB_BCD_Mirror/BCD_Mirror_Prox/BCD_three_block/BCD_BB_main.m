function MSE = BCD_BB_main(Hd,G,Hr,P,sigma)

iter = 0;
% MSE = Nan(10000,1);
[~,N] = size(G); 
[~,K] = size(Hd);
MSE = zeros(300,1);
%% Initialize (Theta W)
W = sqrt(P)*ones(K,1); 
Theta = diag(exp(1i*2*pi*rand(1,N)));

%% parameters for BnB
max_iternum = 1e5; % Maximum number of iterations.
epsilon = 1e-3; % The relative error tolerance.
for i = 1:100
    [f,mse_f] = Updata_Beamforming(Hd,G,Hr,Theta,W,sigma);
    MSE(iter+1) = mse_f;
    [W, mse_w] = Updata_Transmitter(Hd,G,Hr,Theta,f,P,sigma);
    MSE(iter+2) = mse_w;
    [v_opt, final_lb, final_ub, lb_seq, ub_seq] = find_V_BB(W, 1, f, Hr, G, Hd, max_iternum, epsilon);
    Theta = diag(v_opt);
    mse_theta = Calculate_mse(Hd,G,Hr,f,Theta,W,sigma);
    MSE(iter+3) = mse_theta;
    
    iter = iter+3;
end

end
