function [v_opt, final_lb, final_ub, lb_seq, ub_seq] = find_V_BB(omega, eta, m, Hr, G, Hd, max_iternum, epsilon)
% find v
% s.t. |m'Gdiag(hr(:, k))v + m'hd(:, k)| >= 1, k = 1,...,K
%      abs(v_n) = 1,

[M, K] = size(Hr);
l = zeros(M+1, 1);
u = l + 2*pi;

%% initialization
[v, objval, feas] = QpRelaxationV(omega, eta, m, Hr, G, Hd, l, u);

if feas == -1
    error('The solution m is infeasible.\n');
end

A = zeros(max_iternum + 10, M + 2*(M + 1) + 1); 
A(1, :) = [v', l', u', objval];

vt = v./abs(v);
ubest = 0;
for k = 1:K
    ubest = ubest + (norm((omega(k)/sqrt(eta))*m'*G*diag(Hr(:, k))*vt + omega(k)*m'*Hd(:, k) - 1)^2);
end
lbest = objval;
lb_seq = lbest;
ub_seq = ubest;

v_opt = vt;

if (ubest - lbest)/abs(lbest) < epsilon
    final_lb = lbest;
    final_ub = ubest;
    return;
end

%%
iter = 2;
con = 1;
used = 1;
while iter <= max_iternum
    vc = A(con, 1:M)';
    lc = A(con, (M + 1):(2*M + 1))';
    uc = A(con, (2*M + 2):(3*M + 2))';
    
    vt = vc./abs(vc);
    [~, index] = max(abs(vt - vc));
    
    vchild_left_lb = lc;
    vchild_left_ub = uc;
    
    vchild_right_lb = lc;
    vchild_right_ub = uc;
    
    tr =(lc(index) + uc(index))/2;
    
    vchild_left_ub(index) = tr;
    vchild_right_lb(index) = tr;
    
    if con < used
        A(con, :) = A(used, :);
        used = used - 1;
    else
        used = used - 1;
    end
    
    feasl = false;
    feasr = false;
    %% left child
    [v, objval, feas] = QpRelaxationV(omega, eta, m, Hr, G, Hd, vchild_left_lb, vchild_left_ub);
    if feas > 0
        vt = v./abs(v);
        ub = 0;
        for k = 1:K
            ub = ub + (norm((omega(k)/sqrt(eta))*m'*G*diag(Hr(:, k))*vt + omega(k)*m'*Hd(:, k) - 1)^2);
        end
        if ub < ubest
            ubest = ub;
            v_opt = vt;
        end
        A(used + 1, :) = [v', vchild_left_lb', vchild_left_ub', objval];
        used = used + 1;
    else
        feasl = true;
    end
    
    %% right child
    [v, objval, feas] = QpRelaxationV(omega, eta, m, Hr, G, Hd, vchild_right_lb, vchild_right_ub);
    if feas > 0
        vt = v./abs(v);
        ub = 0;
        for k = 1:K
            ub = ub + (norm((omega(k)/sqrt(eta))*m'*G*diag(Hr(:, k))*vt + omega(k)*m'*Hd(:, k) - 1)^2);
        end
        if ub < ubest
            ubest = ub;
            v_opt = vt;
        end
        A(used + 1, :) = [v', vchild_right_lb', vchild_right_ub', objval];
        used = used + 1;
    else
        feasr = true;
    end

    %%
    if feasl && feasr
        error('ACR-BB fails.');
    end
    
    %%
    [lbest, con] = min(A(1:used, 3*(M + 1))); % get min objval
    lb_seq(iter) = lbest;
    ub_seq(iter) = ubest;
    iter = iter + 1;
    if (ubest - lbest)/abs(lbest) < epsilon
        final_lb = lbest;
        final_ub = ubest;
        
        return;
    end
end

%%
final_lb = lbest;
final_ub = ubest;

return;