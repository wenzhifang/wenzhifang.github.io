function minSNR = min_V_SNR(x,A,D,c)

K = size(A,3);
MSE = zeros(K,1);
    for j = 1:K
        MSE(j) = 1/(x'*(-A(:,:,j))*x + 2*x'*D(:,j) + abs(c(j,1))^2);
    end
minSNR = 10*log10(max(MSE));
end

