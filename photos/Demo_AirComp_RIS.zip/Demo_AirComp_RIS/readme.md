## Over-the-Air Computation via Reconfigurable Intelligent Surface ##

1. Demo_AirComp_RIS contain all the algorithms of this paper in matlab code.
2. The repository also contain the implementation of alter SDR and alter DC.
3. BB_BCD_Mirror contain the extra comparison of joint design to uniform-forcing design. Please refer to the **additional_material.pdf**
4. Mirror_Prox_m.m, Mirror_Prox_v.m are the implementations of Mirror Prox method for the optimization of receive beamforming and reflecting phase, respectively .
5. In Compare2SDR.m, Converge_DC_SDR.m and Convergence_Proposed_algorithm.m, we compare our algorithm with alter-SDR and alter- DC, and we check the effect of projection.
6.  small_AP_RIS_20.m and small_AP_RIS_40.m contain the comparisons in low-density scenarios.
7. test_AP_large.m, test_RIS_Elements_large.m, test_user__large.m contain the comparisons in high-density scenarios.
8. If you have any question, please contact fangwzh1@shanghaitech.edu.cn 

@ARTICLE{

9546764,  

author={Fang, Wenzhi and Jiang, Yuning and Shi, Yuanming and Zhou, Yong and Chen, Wei and Letaief, Khaled B.},  journal={IEEE Transactions on Communications},   

title={Over-the-Air Computation via Reconfigurable Intelligent Surface},   

year={2021},  

volume={},  

number={},  

pages={1-1},  

doi={10.1109/TCOMM.2021.3114791}

}