function [m,Theta,mse_set] = alterMin_DC(Hd,Hr,G,iter_max,params,theta)
[N,K] = size(Hd);
[~,M] = size(G);
if nargin<6
    theta = randn(M,1)+1i*rand(M,1);
    theta = theta./abs(theta);
end
Theta = diag(theta);
He = nan(size(Hd));
for k=1:K
    He(:,k) = G*Theta*Hr(:,k)+Hd(:,k);
end
mse_set = nan(iter_max,1);
for ii = 1:iter_max
    
    if params.verb>=2
       fprintf('====iter: %d===find m =======\n',ii) 
    end
    [m,mse,~] = find_M_DC(He,params);
    mse_set(ii) = mse;    
    
    if ii>1 && abs(mse_set(ii)-mse_set(ii-1))<1e-3
        break;
    end
    
%     if check_feasible(theta,m,Hd,Hr,G) == 0
%         error('The solution m is infeasible')
%     end
    
    if params.verb>=2
        fprintf('===iter: %d====find V =======\n',ii)
    end
    [theta,isfeasible] = find_V_DC(m,Hd,Hr,G,params);
    
    if isfeasible == 0
        break;
    else
        Theta = diag(theta);
        He = nan(size(Hd));
        for k=1:K
            He(:,k) = G*Theta*Hr(:,k)+Hd(:,k);
        end
    end
    
end
end