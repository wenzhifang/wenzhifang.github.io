function [mse,feasibility] = SDR_LB(H)
[N,K] = size(H);
c=1e8;
cvx_begin quiet
cvx_solver sdpt3
variable M(N,N) hermitian semidefinite
minimize (real(trace(M*c)))
subject to
for k=1:K
     1-real(H(:,k)'*(M*c)*H(:,k)) <= 0 ;
end
cvx_end
M=M*c;
%% check feasibility
feasibility = 1;
%% compute MSE
mse = 0;
for iter=1:K
    tmp = trace(M)/real(H(:,iter)'*M*H(:,iter));
    if tmp>mse
        mse = tmp;
    end
end
mse = 10*log10(mse);

end