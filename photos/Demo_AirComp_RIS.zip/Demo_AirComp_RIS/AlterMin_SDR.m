%% revised at 20:47 2021-3-30 by Wenzhi Fang

function [m,Theta,mse_set] = AlterMin_SDR(Hd,Hr,G,iter_max,theta)

[N,K] = size(Hd);
[~,M] = size(G);
if nargin<5
    theta = randn(M,1)+1i*rand(M,1);
    theta = theta./abs(theta);
end
Theta = diag(theta);
He = nan(size(Hd));
for k=1:K
    He(:,k) = G*Theta*Hr(:,k)+Hd(:,k);
end
mse_set = nan(iter_max,1);
for ii = 1:iter_max
    %[m,mse,~] = find_M_SDR(He);
    [m, mse] = SDR_Gaussian(He);
    mse_set(ii) = mse;    
%% As do not converge, so we use the same iteration as Proposed algorithm
%     if ii>1 && abs(mse_set(ii)-mse_set(ii-1))<1e-3
%         break;
%     end
    [theta,isfeasible] = find_V_SDR(m,Hd,Hr,G);
    if isfeasible == 0
        break;
    else
        Theta = diag(theta);
        He = nan(size(Hd));
        for k=1:K
            He(:,k) = G*Theta*Hr(:,k)+Hd(:,k);
        end
    end
end
end