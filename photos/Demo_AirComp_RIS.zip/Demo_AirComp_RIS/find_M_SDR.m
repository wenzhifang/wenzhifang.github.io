function [m, mse,feasibility] = find_M_SDR(H)
[N,K] = size(H);
c = 1e8;
cvx_begin quiet
cvx_solver sdpt3
variable M(N,N) hermitian semidefinite
minimize (real(trace(M*c)))
subject to
for k=1:K
     1-real(H(:,k)'*(M*c)*H(:,k)) <= 0 ;
end
cvx_end
M=M*c;
[u,s] = eigs(M);
m = u(:,1)*sqrt(s(1,1));
% m = u(:,1);
%% 
if rank(M,1e-6)>1
    zi = chol(M,'lower');
    xi = (randn(N,1)+1i*randn(N,1))/sqrt(2);
    xi = zi*xi;
    min_eig = inf;
    for k=1:K
        tmp = abs(xi'*H(:,k));
        if tmp<min_eig
            min_eig = tmp;
        end
    end
    m = xi/min_eig;   
end

%% check feasibility
feasibility = 1;
% if check_feasible([],m,H) == 0
%     warning('The solution m is infeasible')
%     feasibility = 0;
%     mse = nan;
%     return;
% end
%  
%% compute MSE
mse = 0;
for iter=1:K
    tmp = norm(m)^2/norm(m'*H(:,iter))^2;
    if tmp>mse
        mse = tmp;
    end
end
mse = 10*log10(mse);

end