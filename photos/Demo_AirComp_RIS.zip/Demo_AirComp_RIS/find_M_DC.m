function [m, mse,feasibility] = find_M_DC(H,params)
maxiter = params.iter_max;
verb = params.verb;
rho = params.rho;
feasibility = 1;
c=1e8;
[N,K] = size(H);
% [m, mse] = SDR_Gaussian(H);
% M_partial = m*m';
% M = m*m';
tmp = randn(N,N)+1i*randn(N,N);
M = tmp*tmp';
[u,~,~] = svd(M);
M_partial = u(:,1)*u(:,1)';
obj0 = 0;
M_former = M; % observe the distance between M^t and M^{t+1}
for  iter = 1:maxiter
    %% Solve convex subproblem
    cvx_begin quiet
    cvx_solver sdpt3
    variable M(N,N) hermitian semidefinite
%     minimize((1+rho)*trace(M)- real(trace(rho*M_partial'* M)))
    minimize (real(trace(((1+rho)*eye(N)-rho*M_partial')*(M*c))))
    subject to
        for k=1:K
            1-real(H(:,k)'*(M*c)*H(:,k)) <= 0 ;
%             1-real(trace(H(:,k)*H(:,k)'*M)) <= 0 ;
        end
    cvx_end
    M = M*c;
    if strcmp(cvx_status,'Infeasible')
        feasibility = 0;
        m = nan;
        return;
    end
    dis = norm(M-M_former,'fro');
    M_former = M;
 
    err = abs(cvx_optval-obj0);
    obj0 = cvx_optval;
    
    %% Subgradient
    [u,s] = eigs(M,1);
    M_partial = u(:,1)*u(:,1)';
    res = abs(norm(M,'fro')-s(1,1));
    %res = trace(s)-s(1,1);
    if verb>=2
        fprintf(' iter:%d/%d, err:%.3e, res:%.3e, dis:%.3e\n', iter, maxiter, err, res,dis);
    end
    if err<1e-1
        break;
    end
    if  res<1e-3&& err<1
        break;
    end
end
[u,s,v] = svd(M);
m = u(:,1)*sqrt(s(1,1));
% m = u(:,1);
% check feasibility
% if check_feasible([],m,H) == 0
%     warning('The solution m is infeasible')
%     feasibility = 0;
%     mse = nan;
%     return;
% end
 
%% compute MSE
mse = 0;
for iter=1:K
    tmp = norm(m)^2/norm(m'*H(:,iter))^2;
    if tmp>mse
        mse = tmp;
    end
end
mse = 10*log10(mse);
end
