%% Created by Wenzhi Fang
%% data : 2020-12-3 22:53
% The convergence behaviour Alter-Mirror-Prox-SCA, AlterMin SDR, and without IRS.
%% revised at 20:47 2021-3-30 by Wenzhi Fang

clearvars;
close all;
clc;
%% RGB color
color1 = [153,0,51]/255;
color2 = [140,168,90]/255;
color3 = [2,76,124]/255;
%% 
N = 50;   %20 No. of Transmit antennas at AP
M = 100;  % No. of elements of RIS
K = 200;  % No. of single antenna IoT devices
SNR = 120; %  SNR dB

[Hr,G,Hd]= channel_realization_IRS(K,M,N);
%[Hr,G,Hd]= channel(M,K,N);
%% Parameter
%% Initialization: m(N,1)[x],v(M,1) 
x = (randn(N,1)+1i.*randn(N,1))./sqrt(2);
x = x/norm(x,2);
x_bar = [real(x);imag(x)];
%%   SDR
[mse,~] = SDR_LB(Hd);
%[~,mse] = SDR_Gaussian(Hd);
sdr_value = mse-SNR;
sdr_value = 10.^(sdr_value/10);
%% 
theta = randn(M,1)+1i*rand(M,1);
theta = theta./abs(theta);
%theta = zeros(M,1);
v_bar = [real(theta);imag(theta)]; 
ksize = num2cell([N,K,M]);
%% Alternating Mirror prox based SCA
re = zeros(10,1);
for iter = 1:5
[x_bar,min_SNR_MP1] = Mirror_Prox_m(Hd,G,Hr,ksize,x_bar,v_bar);
re(2*iter-1,1) = min_SNR_MP1(end,1);
[v_bar,min_SNR_MP2] = Mirror_Prox_v(Hd,G,Hr,ksize,x_bar,v_bar);
value = min_SNR_MP2 - SNR; % SNR = SNR dB
value = 10.^(value/10);
semilogy(value,'-*','LineWidth',2,'color',color3,'MarkerSize',8);
re(2*iter,1) = min_SNR_MP2(end,1);
end
value = re - SNR;
value = 10.^(value/10);
project_MSE = post_projection(Hd,G,Hr,ksize,x_bar,v_bar);
project_value = project_MSE - SNR;
project_value = 10.^(project_value/10);
project_value_set = ones(10,1)*project_value;

x = 1:1:10;
semilogy(x,value,'-o','LineWidth',2,'color',color1,'MarkerSize',8);
hold on
semilogy(x,project_value_set,'-','LineWidth',2,'color',color3,'MarkerSize',8);
grid on
% set(gca, 'YLimMode', 'manual');
% set(gca, 'YLim', [2e-3, 2e-2]);
xlabel('Number of iteration','interpreter','latex','FontSize',14)
ylabel('\bf MSE','interpreter','latex','FontSize',14)
legend({'N=100 ,M=10, K=200, pre-projection', 'N=100 ,M=10, K=200, post-projection'},'interpreter','latex','FontSize',14)