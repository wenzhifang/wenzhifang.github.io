%%  2020-12-4     fang wenzhi
%% revised 2021-3-31
clc,clear,close all;
%% parameter settings
K = 200; % # of users
M = 50; % # of elements
exp_num = 500;
N_set = 10:10:100;
iter_max = 6;

mse_wo_IRS = nan(length(N_set),1);

mse_MP_IRS = nan(length(N_set),1);
mse_rndV_IRS = nan(length(N_set),1);
mse_IRS_SDR = nan(length(N_set),1);
T_MP = nan(length(N_set),1);
T_SDR = nan(length(N_set),1);
parpool(50)
for ii = 1:length(N_set)
    N = N_set(ii);
    %% MSE  
    tmp_wo_IRS = 0;
    tmp_MP_IRS = 0;
    tmp_rndV_IRS = 0;
    tmp_SDR = 0;
    %% time
    tmp_t_MP = 0;
    tmp_t_SDR = 0;
    fprintf('AP Number = %d\n',N)
    parfor jj = 1:exp_num
        jj
        [Hr,G,Hd]= channel_realization_IRS(K,M,N);
        %% Mirror_Prox
        tic
        [re] = Mirror_Prox(N,M,K,Hd,Hr,G);
        tmp_T = toc;
      
        tmp_t_MP = tmp_t_MP + tmp_T;
        tmp_MP_IRS = tmp_MP_IRS + re(end);
        tmp_rndV_IRS = tmp_rndV_IRS + re(1);
        
        %% SDR
        tic
        [~,~,mse_SDR] = AlterMin_SDR(Hd,Hr,G,iter_max);
        tmp_T = toc;
        tmp_t_SDR = tmp_t_SDR + tmp_T;
        tmp = mse_SDR(~isnan(mse_SDR));
        tmp_SDR = tmp_SDR+tmp(end);
        disp('sdr');
        
        %% wo
        [mse_wo,~] = SDR(Hd);
        tmp_wo_IRS = tmp_wo_IRS + mse_wo;  
    
    end
    mse_wo_IRS(ii) = tmp_wo_IRS/exp_num;
    mse_MP_IRS(ii) = tmp_MP_IRS/exp_num;
    mse_rndV_IRS(ii) = tmp_rndV_IRS/exp_num;
    mse_IRS_SDR(ii) = tmp_SDR/exp_num;
    T_MP(ii) = tmp_t_MP/exp_num;
    T_SDR(ii) = tmp_t_SDR/exp_num;
    
end
% save main_IRS_antenna.mat
wo_value = mse_wo_IRS - 120;
wo_value = 10.^(wo_value/10);
mse_MP_IRS_value = mse_MP_IRS - 120;
mse_MP_IRS_value = 10.^(mse_MP_IRS_value/10);
mse_rndV_IRS_value = mse_rndV_IRS - 120;
mse_rndV_IRS_value = 10.^(mse_rndV_IRS_value/10);
mse_IRS_SDR_value = mse_IRS_SDR - 120;
mse_IRS_SDR_value = 10.^(mse_IRS_SDR_value/10);

save ./large/dataAP.mat
