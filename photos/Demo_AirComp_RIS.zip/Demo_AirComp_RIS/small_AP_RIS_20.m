%%  2020-126     fang wenzhi
%% Comparision of AlterMin SDR and Alter-MP-SCA
clc,clear,close all;
%% Parameter settings
K = 10; % # of users
M = 20; % # RIS
exp_num = 500; % Monter Carlo Average
N_set = 5:5:25; % elements
params.iter_max = 100;
params.verb = 1;
params.rho = 5;
iter_max = 10;
params.snr = 1;

mse_MP_IRS = nan(length(N_set),1);
mse_dc = nan(length(N_set),1);
mse_IRS_SDR = nan(length(N_set),1);
T_MP = nan(length(N_set),1);
T_SDR = nan(length(N_set),1);
T_DC = nan(length(N_set),1);
parpool(50)
for ii = 1:length(N_set)
    N = N_set(ii);
    %% MSE 
   
    tmp_MP_IRS = 0;
    tmp_DC = 0;
    tmp_SDR = 0;
    %% time
    tmp_t_MP = 0;
    tmp_t_SDR = 0;
    tmp_t_DC = 0;
    fprintf('Antennas Number = %d\n',N)
    parfor jj = 1:exp_num
        disp(jj)
        [Hr,G,Hd]= channel_realization_IRS(K,M,N);
        %% Mirror_Prox
        tic
        [re] = Mirror_Prox(N,M,K,Hd,Hr,G);
        tmp_T = toc;
       
        tmp_t_MP = tmp_t_MP + tmp_T;
        tmp_MP_IRS = tmp_MP_IRS + re(end);
        
        %% SDR
        tic
        [~,~,mse_SDR] = AlterMin_SDR(Hd,Hr,G,iter_max);
        tmp_T = toc;
        tmp_t_SDR = tmp_t_SDR + tmp_T;
        tmp = mse_SDR(~isnan(mse_SDR));
        tmp_SDR = tmp_SDR+tmp(end);
        
        %% DC
        tic
        [~,~, mse_DC] = alterMin_DC(Hd,Hr,G,iter_max,params);
        tmp_T = toc;
        tmp_t_DC = tmp_T;
        tmp = mse_DC(~isnan(mse_DC));
        tmp_DC = tmp_DC+tmp(end);
        
        
        disp('sdr');
      
    end
    mse_MP_IRS(ii) = tmp_MP_IRS/exp_num;
    mse_dc(ii) = tmp_DC/exp_num;
    mse_IRS_SDR(ii) = tmp_SDR/exp_num;
    T_MP(ii) = tmp_t_MP/exp_num;
    T_SDR(ii) = tmp_t_SDR/exp_num;
    T_DC(ii) = tmp_DC/exp_num;
    
end
% save main_IRS_antenna.mat
mse_MP_IRS_value = mse_MP_IRS - 120;
mse_MP_IRS_value = 10.^(mse_MP_IRS_value/10);
mse_dc_value = mse_dc - 120;
mse_dc_value = 10.^(mse_dc_value/10);
mse_IRS_SDR_value = mse_IRS_SDR - 120;
mse_IRS_SDR_value = 10.^(mse_IRS_SDR_value/10);
save ./small/dataAP_RIS20.mat
