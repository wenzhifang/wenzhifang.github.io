clc, clear,close all;
K = 10;     %K: number of IoT devices
N = 5;      %N: number of antenna at AP
M = 20;     %M: number of elements at IRS
SNR = 120;  %SNR: 120 dB


[Hr,G,Hd]= channel_realization_IRS(K,M,N);
params.iter_max = 1000;
params.verb = 2;
params.rho = 5;
iter_max = 10;

theta = randn(M,1)+1i*rand(M,1);
theta = theta./abs(theta);
[m,~, mse_dc] = alterMin_DC(Hd,Hr,G,iter_max,params,theta);
[m,~, mse_sdr] = AlterMin_SDR(Hd,Hr,G,iter_max,theta); % dB

sdr_value = mse_sdr-SNR;
sdr_value = sdr_value(~isnan(sdr_value));
sdr_value = 10.^(sdr_value/10);

dc_value = mse_dc-SNR;
dc_value = dc_value(~isnan(sdr_value));
dc_value = 10.^(dc_value/10);

x = length(sdr_value);
semilogy(1:1:x,sdr_value,'-d','LineWidth',2,'MarkerSize',8);
hold on
x = length(dc_value);
semilogy(1:1:x,dc_value,'-d','LineWidth',2,'MarkerSize',8);
grid on
xlabel('Number of iteration','interpreter','latex','FontSize',14)
ylabel('\bf MSE','interpreter','latex','FontSize',14)
legend({'Alternating SDR','Alternating DC'},'interpreter','latex','FontSize',14)
